The navigation profile of "Accurate Groves solution" is organized as n x 10 matrix, where n equals the number of measurement epochs. The columns are organized as follows:

1) GPS Time
2) Lat
3) Long
4) height
5) Velocity north
6) velocity east
7) velocity down
8) roll
9) pitch
10) yaw

